from pathlib import Path
p=Path('/workspace/airi-experiment/retention-system-trial.py')
s=p.read_text()
s=s.replace('    schedule=SCHEDULE\n','    resume_interrupted="--resume-new" in sys.argv\n    prior_report=json.loads(args.output.read_text()) if resume_interrupted else None\n    schedule=SCHEDULE\n',1)
s=s.replace('    before = evaluate(champion)\n','    before = prior_report["baseline"] if resume_interrupted else evaluate(champion)\n',1)
s=s.replace("    json_write(args.output,report)\n    print(json.dumps(dict(phase='pretraining ready'",'''    if prior_report:
        if (prior_report['common_acquisition_anchor_sha256']!=report['common_acquisition_anchor_sha256']
                or prior_report['predeclared_profile']!=report['predeclared_profile']
                or prior_report['source_files']!=report['source_files']):
            raise AssertionError('interrupted resume changed predeclared source/profile/trajectory')
        report=prior_report
        report['interruption']={'reason':'Harness compared Torch RNG after reload constructor had consumed it; all weights/Adam/statistics/bank/sampler checks passed',
            'recovery':'Continue saved native/Adam/JSON midpoint64, unchanged fixed192 logical trajectory; original development endpoint not repeated',
            'extra_discarded_physical_optimizer_attempts':2,
            'extra_discarded_attempts_timing_seconds':None,
            'missing_timing_reason':'Process-local clocks were lost on harness assertion; exact extra token exposures reconstructed from independently reproduced unit65'}
    json_write(args.output,report)
    print(json.dumps(dict(phase='pretraining ready' ''',1)
s=s.replace("    for arm in ('old-uniform-target-kl','new-persistent-transactional'):\n        torch.manual_seed(args.seed)\n        runtime=GeneralistRuntime.from_checkpoint(args.checkpoint)",'''    for arm in ('old-uniform-target-kl','new-persistent-transactional'):
        if any(t['arm']==arm for t in report['trials']):continue
        resuming=resume_interrupted and arm.startswith('new')
        resume_dir=args.output.parent/'retention-system-trial-new-midpoint'
        torch.manual_seed(args.seed)
        runtime=GeneralistRuntime.from_checkpoint(resume_dir if resuming else args.checkpoint)''',1)
s=s.replace('''        cert_candidate=make_certifier(runtime.model,encode,EOS)
        def unit''','''        cert_candidate=make_certifier(runtime.model,encode,EOS)
        start_index=0
        if resuming:
            saved=json.loads((resume_dir/'TRAINING_STATE.json').read_text())
            saved_opt=torch.load(resume_dir/'OPTIMIZER.pt',weights_only=True)
            optimizer.load_state_dict(saved_opt['optimizer'])
            for name,p in runtime.model.named_parameters():
                if p.requires_grad:p.grad=saved_opt['gradients'][name]
            current_bank=saved['bank'];adaptive=saved['transaction']
            memory_rng.setstate(tuples(saved['memory_rng']));guard_rng.setstate(tuples(saved['guard_rng']))
            torch.set_rng_state(torch.tensor(saved['torch_rng'],dtype=torch.uint8))
            segments=deepcopy(report['running_trial']['segments'])
            accounting=deepcopy(segments[-1]['accounting'])
            start_index=64
            del saved,saved_opt
        def unit''',1)
s=s.replace('        for index in range(args.steps):\n','        for index in range(start_index,args.steps):\n',1)
s=s.replace('''                restored=GeneralistRuntime.from_checkpoint(resume_dir)
''','''                current_torch_rng=torch.get_rng_state().clone()
                restored=GeneralistRuntime.from_checkpoint(resume_dir)
''',1)
s=s.replace('''                current_torch_rng=torch.get_rng_state().clone()
                torch.set_rng_state(torch.tensor(saved['torch_rng'],dtype=torch.uint8))''','''                torch.set_rng_state(torch.tensor(saved['torch_rng'],dtype=torch.uint8))''',1)
s=s.replace('''                resume.update(checks);resume['verification_pending']=False
''','''                resume.update(checks);resume['verification_pending']=False
                if resuming:
                    extra=report['interruption']
                    for kind in ('supervised_tokens','reference_tokens','prompt_reference_tokens'):
                        extra['extra_discarded_physical_'+kind]=2*update['stats'].get(kind,0)
''',1)
s=s.replace('''            update_ledger=updates,knowledge_growth_ledger=ledger,after=after,''','''            update_ledger=updates,update_ledger_scope='units65..192 with first64 aggregate in segment checkpoint' if resuming else 'all192 units',
            knowledge_growth_ledger=ledger,after=after,''',1)
s=s.replace("        report['trials'].append(trial);report.pop('running_trial',None)",'''        if resuming:
            trial['interruption_extra_physical_accounting']=deepcopy(report['interruption'])
            trial['physical_attempts_including_resume_validation_and_discarded']=accounting['physical_attempts']+validation_accounting['physical_attempts']+2
            trial['physical_tokens_including_resume_validation_and_discarded']={
                kind:accounting['physical_'+kind]+validation_accounting['physical_'+kind]+report['interruption']['extra_discarded_physical_'+kind]
                for kind in ('supervised_tokens','reference_tokens','prompt_reference_tokens')}
        report['trials'].append(trial);report.pop('running_trial',None)''',1)
p.write_text(s)
