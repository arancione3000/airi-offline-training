"""TRAIN-only native context sensitivity; never updates model parameters.

The auxiliary ridge classifiers are diagnostic readouts fit exclusively to
authored TRAIN examples, with one TRAIN template held out per fold. Their
accuracy is not the language-model benchmark or a qualification result.
"""
import argparse
import hashlib
import json
from pathlib import Path
import sys

import torch
from torch.nn import functional as F

sys.path.insert(0, '/workspace/airi-offline-training/scripts/transfer-training')
from continual_learning import cache_tokenizer
from generalist_lm.runtime import GeneralistRuntime, checkpoint_model_files


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--checkpoint', required=True, type=Path)
    p.add_argument('--archive', type=Path, default=Path('/workspace/airi-experiment/state/experiment'))
    p.add_argument('--output', required=True, type=Path)
    args = p.parse_args()
    torch.set_num_threads(2)
    torch.manual_seed(20261103)
    files = checkpoint_model_files(args.checkpoint, verify=True)
    hashes = {str(f): digest(f) for f in files}
    rt = GeneralistRuntime.from_checkpoint(args.checkpoint)
    rt.model.eval()
    for parameter in rt.model.parameters():
        parameter.requires_grad_(False)
    cache_tokenizer(rt.tokenizer)
    data_path = args.archive / 'AUTHORED_CURRICULUM.json'
    data = json.loads(data_path.read_text())
    # No development/final example is selected, encoded or forwarded.
    selected = [r for r in data['train'] if r['family'] == 'context-name' and r.get('stage') == 0]
    if len(selected) != 64:
        raise ValueError('unexpected exact stage0 TRAIN population')
    names = sorted({r['expected'] for r in selected})
    if len(names) != 8:
        raise ValueError('unexpected TRAIN name population')
    features = {}
    records = []
    handles = []
    current = {}

    def capture_input(module, inputs):
        current['embedding'] = inputs[0].detach()

    def capture_output(index):
        def hook(module, inputs, output):
            current[f'block{index}'] = output[0].detach()
        return hook

    handles.append(rt.model.blocks[0].register_forward_pre_hook(capture_input))
    for index, block in enumerate(rt.model.blocks):
        handles.append(block.register_forward_hook(capture_output(index)))

    def encoded(row):
        content = row['messages'][0]['content']
        raw = content.encode('utf-8')
        needle = row['expected'].encode('utf-8')
        start = raw.index(needle)
        end = start + len(needle)
        prompt = rt.tokenizer.serialize_messages(row['messages'][:-1], add_generation_prompt=True)
        # Serialized first user message begins after BOS and USER role tokens.
        spans, offset = [], 0
        for i, token in enumerate(rt.tokenizer.encode(content)):
            n = len(rt.tokenizer.token_bytes(token))
            if offset < end and offset + n > start:
                spans.append(i + 2)
            offset += n
        if not spans:
            raise ValueError('TRAIN source value was not located')
        template = content.replace(row['expected'], '{TRAIN_VALUE}')
        return torch.tensor([prompt]), spans, template

    try:
        with torch.no_grad():
            for row in selected:
                ids, spans, template = encoded(row)
                current.clear()
                logits = rt.model(ids)['logits']
                gold = rt.tokenizer.encode(row['expected'], eos=True)[0]
                record = {'language': row['language'], 'value': row['expected'],
                          'template': template, 'prompt_tokens': ids.shape[1],
                          'source_positions': spans,
                          'first_gold_probability': float(logits[0, -1].softmax(-1)[gold]),
                          'first_prediction': rt.tokenizer.decode([int(logits[0, -1].argmax())])}
                records.append(record)
                for layer, hidden in current.items():
                    for place, vector in [('source_mean', hidden[0, spans].mean(0)),
                                          ('source_last', hidden[0, spans[-1]]),
                                          ('question_tail', hidden[0, -1])]:
                        features.setdefault((layer, place), []).append(vector.cpu().double())
    finally:
        for handle in handles:
            handle.remove()

    readouts = []
    for language in ('it', 'en'):
        indices = [i for i, r in enumerate(records) if r['language'] == language]
        templates = sorted({records[i]['template'] for i in indices})
        if len(templates) != 4:
            raise ValueError('expected four TRAIN templates per language')
        for (layer, place), values in features.items():
            X = torch.stack(values)
            correct = 0
            by_template = []
            for template in templates:
                fit = [i for i in indices if records[i]['template'] != template]
                test = [i for i in indices if records[i]['template'] == template]
                mean = X[fit].mean(0)
                train = F.normalize(X[fit] - mean, dim=-1)
                target = F.one_hot(torch.tensor([names.index(records[i]['value']) for i in fit]), 8).double()
                gram = train @ train.T
                coefficients = torch.linalg.solve(gram + .01 * torch.eye(len(fit), dtype=torch.double), target)
                predictions = (F.normalize(X[test] - mean, dim=-1) @ train.T @ coefficients).argmax(-1)
                hits = sum(int(v) == names.index(records[i]['value']) for v, i in zip(predictions, test))
                correct += hits
                by_template.append({'template': template, 'correct': hits, 'rows': len(test)})
            # Template-balanced within/between-name cosine distances. This
            # accounts for multiple prompts, though positions still vary.
            normed = F.normalize(X[indices], dim=-1)
            distance = 1 - normed @ normed.T
            same, different = [], []
            for a, i in enumerate(indices):
                for b, j in enumerate(indices):
                    if a >= b:
                        continue
                    (same if records[i]['value'] == records[j]['value'] else different).append(float(distance[a, b]))
            readouts.append({'language': language, 'layer': layer, 'position': place,
                             'train_template_cv_correct': correct, 'rows': len(indices),
                             'classes': 8, 'chance_accuracy': .125,
                             'accuracy': correct / len(indices), 'ridge': .01,
                             'mean_same_value_cosine_distance': sum(same) / len(same),
                             'mean_different_value_cosine_distance': sum(different) / len(different),
                             'folds': by_template})

    # Input-gradient attribution at the final block, without parameter grads
    # or optimizer updates. Hidden source information can also already be in
    # later positions; this attribution is not an exclusive information path.
    gradients = []
    for language in ('it', 'en'):
        rows = [r for r in selected if r['language'] == language and
                r['messages'][0]['content'].startswith('Il mio nome' if language == 'it' else 'My name')]
        for row in rows:
            ids, spans, _ = encoded(row)
            leaf = {}
            def capture_leaf(module, inputs):
                value = inputs[0].detach().requires_grad_(True)
                leaf['value'] = value
                return (value,)
            handle = rt.model.blocks[-1].register_forward_pre_hook(capture_leaf)
            try:
                output = rt.model(ids)['logits'][0, -1]
                gold = rt.tokenizer.encode(row['expected'], eos=True)[0]
                loss = F.cross_entropy(output.unsqueeze(0), torch.tensor([gold]))
                grad, = torch.autograd.grad(loss, leaf['value'])
                norm = grad[0].norm(dim=-1)
                total = float(norm.sum())
                gradients.append({'language': language, 'value': row['expected'],
                                  'first_gold_loss': float(loss.detach()),
                                  'first_gold_probability': float(output.softmax(-1)[gold].detach()),
                                  'source_gradient_fraction': float(norm[spans].sum()) / total,
                                  'tail_gradient_fraction': float(norm[-1]) / total,
                                  'gradient_norm_sum': total,
                                  'source_positions': spans})
            finally:
                handle.remove()

    positional = rt.model.position_embedding.weight.detach()
    result = {'scope': 'TRAIN-only diagnostic; no optimizer, no parameter updates, no development or final forward passes',
              'checkpoint': str(args.checkpoint), 'model_files_sha256': hashes,
              'authored_curriculum_sha256': digest(data_path), 'rows': len(selected),
              'names': names, 'readout_note': 'auxiliary ridge readout learns TRAIN name identity; not model capability or an inference adapter',
              'gradient_note': 'final-block input sensitivity; source information can also flow through already-contextualized tail positions',
              'readouts': readouts, 'input_gradients': gradients, 'records': records,
              'position_norm_first128': float(positional[:128].norm(dim=-1).mean()),
              'position_norm_after128': float(positional[128:].norm(dim=-1).mean()),
              'all_parameter_gradients_absent': all(p.grad is None for p in rt.model.parameters())}
    if any(digest(Path(name)) != value for name, value in hashes.items()):
        raise AssertionError('source model changed')
    result['source_checkpoint_unchanged'] = True
    args.output.write_text(json.dumps(result, indent=2, allow_nan=False))
    summary = [r for r in readouts if r['layer'] in {'embedding', 'block0', 'block3', 'block7', 'block10', 'block11'}]
    print(json.dumps({'rows': result['rows'], 'readouts': [{k:v for k,v in r.items() if k != 'folds'} for r in summary],
                      'input_gradients': gradients, 'source_checkpoint_unchanged': True}, indent=2), flush=True)


if __name__ == '__main__':
    main()
