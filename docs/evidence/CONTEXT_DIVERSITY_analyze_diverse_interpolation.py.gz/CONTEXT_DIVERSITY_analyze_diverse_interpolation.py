"""Read-only original-development measurement of existing native weights.
No optimizer, no training, no sealed/final evaluation, no model adoption.
"""
import sys
from pathlib import Path
ARCHIVE=Path('/workspace/airi-experiment/revision2/experiment')
sys.path.insert(0,str(ARCHIVE))
sys.path.insert(1,'/workspace/airi-offline-training/scripts/transfer-training')
import json,hashlib,time,statistics
import torch
from torch.nn import functional as F
from generalist_lm.runtime import GeneralistRuntime,checkpoint_model_files
from generalist_lm.training import SFTExample,encode_sft_example
from generalist_lm.phase5_diagnostics import protected_bootstrap_texts
from continual_learning import cache_tokenizer,try_interpolations
from curriculum import norm,exact_correct,repetitive
from success_bank import retains_correct_answers
from human_data import load_corpus
from policy import improved,reward
from fast_head import install_feature_cache
from prefix_tuning import configure_prefix_tuning

torch.set_num_threads(2)
ROOT=Path('/workspace/airi-experiment')
SOURCE=ROOT/'revision2/checkpoint/model'
TRIALFILE=ROOT/'context-values-paired-512.json'
REPORT=ROOT/'diverse-interpolation-evidence.json'
prior=json.loads(TRIALFILE.read_text())
base_saved=json.loads((ROOT/'completed-cycle/FINAL_RESULT.json').read_text())['counters']['champion']
diverse=next(t for t in prior['trials'] if t['mode']=='diverse-paired')
CANDIDATE=Path(diverse['candidate'])

def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
source_hashes={str(p):digest(p) for p in checkpoint_model_files(SOURCE,verify=True)}
candidate_hashes={str(p):digest(p) for p in checkpoint_model_files(CANDIDATE,verify=True)}
assert source_hashes==prior['source_files']
print(json.dumps({'phase':'loading source/candidate, immutable manifest hashes verified'}),flush=True)
champion=GeneralistRuntime.from_checkpoint(SOURCE)
cache_tokenizer(champion.tokenizer)
champion.model.eval()
for p in champion.model.parameters():p.requires_grad_(False)
install_feature_cache(champion.model,cache_bytes=128*1024*1024)
runtime=GeneralistRuntime.from_checkpoint(CANDIDATE)
cache_tokenizer(runtime.tokenizer)
configure_prefix_tuning(runtime.model)
runtime.model.eval()

# Reproduce the exact filtered original development pools. Final records below
# are read only by the original overlap filter and are never evaluated.
dataset=json.loads((ARCHIVE/'AUTHORED_CURRICULUM.json').read_text())
authored,heldout=dataset['train'],dataset['development']
spec=json.loads((ARCHIVE/'SPEC.json').read_text())
old_validation=[json.loads(line) for name in ('development.jsonl','test.jsonl') for line in (ARCHIVE/name).read_text().splitlines()]
legacy_blocked={norm(m['content']) for row in old_validation for m in row['messages']}
protected=protected_bootstrap_texts()|legacy_blocked
old_train=[json.loads(line) for line in (ARCHIVE/'train-1024.jsonl').read_text().splitlines()]
old_train=[r for r in old_train if not any(norm(m['content']) in protected for m in r['messages'])]
old_human=[r for r in old_train if 2<=len(r['messages'])<=6 and 12<=len(r['messages'][-1]['content'].encode())<=480]
previous_text={norm(m['content']) for r in old_human for m in r['messages']}
blocked=legacy_blocked|{norm(p) for p in json.loads((ARCHIVE/'CONVERSATION_TEST.json').read_text())['prompts']}
all_heldout={norm(m['content']) for r in heldout for m in r['messages']}
acquisition_blocked=blocked|all_heldout|{norm(m['content']) for r in authored for m in r['messages']}
corpus=load_corpus(ARCHIVE,spec['human_corpus']['pins'],acquisition_blocked|previous_text,training_blocked=acquisition_blocked)
human_dev=[r for lang in ('it','en') for r in [r for r in corpus['development'] if r['language']==lang][:16]]
encoded={}
def encode(row):
    key=json.dumps(row['messages'],sort_keys=True,ensure_ascii=False)
    if key not in encoded:
        ids,labels=encode_sft_example(SFTExample.from_dict(row),champion.tokenizer,1024,require_complete=True)
        width=int((labels!=-100).nonzero()[:,0].max())+1
        encoded[key]=ids[:width].unsqueeze(0),labels[:width].unsqueeze(0)
    return encoded[key]
validation=[encode(r) for r in heldout]
human_validation=[encode(r) for r in human_dev]

def evaluate(rt):
    rt.model.eval()
    def grouped_nll(rows,batches):
        out={}
        with torch.no_grad():
            for lang in ('it','en'):
                total,count=0.,0
                for row,(ids,labels) in zip(rows,batches):
                    if row['language']!=lang:continue
                    logits=rt.model(ids)['logits'][:,:-1]
                    total+=float(F.cross_entropy(logits.reshape(-1,logits.shape[-1]),labels[:,1:].reshape(-1),reduction='sum'))
                    count+=int((labels[:,1:]!=-100).sum())
                if count:out[lang]=total/count
        return out
    nll=grouped_nll(heldout,validation)
    human_nll=grouped_nll(human_dev,human_validation)
    samples=[]
    with torch.no_grad():
        for old in base_saved['samples']:
            response=rt.chat(old['messages'],temperature=0,max_new_tokens=64)
            samples.append({**old,'response':response,'correct':exact_correct(response,old['expected'])})
    contexts=[s for s in samples if s['family'].startswith('context-')]
    rates={f'{lang}:{task}':sum(s['correct'] for s in contexts if s['language']==lang and s['family']=='context-'+task)/sum(1 for s in contexts if s['language']==lang and s['family']=='context-'+task) for lang in ('it','en') for task in ('name','location','topic','correction')}
    pairs={s['pair_id'] for s in contexts}
    return {'human_nll':human_nll,'human_development_rows':len(human_dev),'nll':nll,'foundation_correct':sum(s['correct'] for s in samples if s['family'].startswith('foundation-')),'foundation_probes':sum(s['family'].startswith('foundation-') for s in samples),'context_rates':rates,'context_pair_rate':sum(all(s['correct'] for s in contexts if s['pair_id']==p) for p in pairs)/len(pairs),'legacy_correct':sum(s['correct'] for s in samples if not s['family'].startswith(('extra-','context-','foundation-'))),'dialogue_correct':sum(s['correct'] for s in samples if s['family'].startswith('extra-')),'exact_correct':sum(s['correct'] for s in samples),'probes':len(samples),'repetition':sum(repetitive(s['response']) for s in samples)/len(samples),'samples':samples}

def first_tokens(rt):
    rows=[]
    with torch.no_grad():
        for index,s in enumerate(base_saved['samples']):
            if not s['family'].startswith('context-'):continue
            ids=torch.tensor([rt.tokenizer.serialize_messages(s['messages'],add_generation_prompt=True)])
            logits=rt.model(ids)['logits'][0,-1]
            target=rt.tokenizer.encode(s['expected'],eos=True)[0]
            prob=float(torch.softmax(logits,dim=-1)[target])
            rank=int((logits>logits[target]).sum())+1
            top=int(logits.argmax())
            rows.append({'sample_index':index,'language':s['language'],'family':s['family'],'expected':s['expected'],'target_first_token':target,'target_probability':prob,'target_rank':rank,'top_token':top,'top_equals_target':top==target})
    groups={}
    for lang in ('it','en'):
        for task in ('name','location','topic','correction'):
            group=[r for r in rows if r['language']==lang and r['family']=='context-'+task]
            groups[lang+':'+task]={'count':len(group),'target_probability_mean':statistics.mean(r['target_probability'] for r in group),'target_rank_mean':statistics.mean(r['target_rank'] for r in group),'target_rank_median':statistics.median(r['target_rank'] for r in group),'first_token_top1':sum(r['top_equals_target'] for r in group)}
    return {'scope':'first byte token for the fixed original context development generation prompts; teacher-free probability diagnostic, not a new answer or sealed result','by_family':groups,'rows':rows}

def comparison(before,after):
    lost=[i for i,(a,b) in enumerate(zip(before['samples'],after['samples'])) if a['correct'] and not b['correct']]
    gained=[i for i,(a,b) in enumerate(zip(before['samples'],after['samples'])) if not a['correct'] and b['correct']]
    return {'development_gate_accepted':bool(improved(before,after) and retains_correct_answers(before,after)),'policy_improved':bool(improved(before,after)),'retains_correct_answers':bool(retains_correct_answers(before,after)),'lost_answers':lost,'gained_answers':gained,'old_answers_retained':before['exact_correct']-len(lost),'new_correct_answers':len(gained),'reward':reward(after)}

report={'scope':'read-only measurement of existing revision2 and diverse512 native candidate on exact original development only; no optimizer/training; both existing interpolation factors measured independently; no model adopted','source_checkpoint':str(SOURCE),'candidate':str(CANDIDATE),'source_sha256':source_hashes,'candidate_sha256':candidate_hashes,'original_trial_report_sha256':digest(TRIALFILE),'evaluation_rows':{'authored_nll':len(heldout),'human_nll':len(human_dev),'generation':len(base_saved['samples']),'context_generation':sum(s['family'].startswith('context-') for s in base_saved['samples'])},'sealed_final_evaluated':False,'live_promoted':False,'production_qualified':False,'interpolation_factors_preexisting':[.5,.25],'interpolation_results':[]}
start=time.monotonic()
before=evaluate(champion)
assert before['exact_correct']==base_saved['exact_correct']
assert before['samples']==base_saved['samples']
assert all(abs(before['nll'][k]-v)<1e-5 for k,v in base_saved['nll'].items())
assert all(abs(before['human_nll'][k]-v)<1e-5 for k,v in base_saved['human_nll'].items())
report['baseline_reproduced']=True
report['baseline']=before
report['first_token_diagnostics']={'baseline':first_tokens(champion),'diverse_endpoint':first_tokens(runtime)}
report['recorded_endpoint']={**comparison(before,diverse['after']),'metrics':diverse['after'],'native_export_logits_exact_recorded':diverse['native_export_logits_exact']}
REPORT.write_text(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False))
print(json.dumps({'phase':'baseline reproduced / endpoint token diagnostic done','seconds':time.monotonic()-start}),flush=True)

alphas=iter((.5,.25))
def assess():
    alpha=next(alphas)
    tick=time.monotonic()
    metrics=evaluate(runtime)
    entry={'alpha':alpha,**comparison(before,metrics),'metrics':metrics,'first_token_diagnostic':first_tokens(runtime),'evaluation_seconds':time.monotonic()-tick}
    report['interpolation_results'].append(entry)
    REPORT.write_text(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False))
    print(json.dumps({'phase':'interpolation complete',**{k:entry[k] for k in ('alpha','development_gate_accepted','old_answers_retained','new_correct_answers','lost_answers','gained_answers')},'exact_correct':metrics['exact_correct'],'nll':metrics['nll'],'human_nll':metrics['human_nll'],'seconds':entry['evaluation_seconds']}),flush=True)
    return metrics
# Always false: measurements are recorded, but neither candidate is adopted.
result=try_interpolations(runtime.model,champion.model,evaluate=assess,acceptable=lambda m:False,alphas=(.5,.25))
assert result['alpha'] is None and result['probes']==2
assert all(digest(p)==v for p,v in source_hashes.items())
assert all(digest(p)==v for p,v in candidate_hashes.items())
report['source_checkpoint_unchanged']=True
report['candidate_checkpoint_unchanged']=True
report['interpolation_candidate_restored']=True
report['no_adoption']=True
report['wall_seconds']=time.monotonic()-start
REPORT.write_text(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False))
print(json.dumps({'phase':'read-only evidence complete','output':str(REPORT),'wall_seconds':report['wall_seconds']}),flush=True)
