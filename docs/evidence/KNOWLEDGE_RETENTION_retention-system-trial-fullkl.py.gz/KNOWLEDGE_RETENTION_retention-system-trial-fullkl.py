"""Read-only exhaustive TRAIN-bank functional audit; no optimizer or eval rows."""
import sys
sys.path.insert(0,'/workspace/airi-offline-training/scripts/transfer-training')
from pathlib import Path
import hashlib,json,time
import torch
from torch.nn import functional as F
from generalist_lm.runtime import GeneralistRuntime,checkpoint_model_files
from generalist_lm.training import SFTExample,encode_sft_example
from fast_head import install_feature_cache
from prefix_tuning import configure_prefix_tuning
from retention_guard import full_sequence_kl

root=Path('/workspace/airi-experiment')
output=root/'retention-system-trial.json'
report=json.loads(output.read_text())
if not report.get('complete'):raise ValueError('bounded training trial must finish before read-only audit')
trial=next(t for t in report['trials'] if t['arm']=='new-persistent-transactional')
bank=json.loads((root/'retention-system-trial-initial-bank.json').read_text())
checkpoint=root/'revision2/checkpoint/model'
source_hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in checkpoint_model_files(checkpoint,verify=True)}
torch.set_num_threads(2)
champion=GeneralistRuntime.from_checkpoint(checkpoint)
candidate=GeneralistRuntime.from_checkpoint(trial['candidate'])
for p in champion.model.parameters():p.requires_grad_(False)
install_feature_cache(champion.model,cache_bytes=64*1024*1024)
configure_prefix_tuning(candidate.model)
champion.model.eval();candidate.model.eval()
records={};start=time.monotonic()
with torch.no_grad():
    for index,(key,entry) in enumerate(sorted(bank['entries'].items()),1):
        row=entry['row']
        ids,labels=encode_sft_example(SFTExample.from_dict(row),champion.tokenizer,1024,require_complete=True)
        width=int((labels!=-100).nonzero()[:,0].max())+1
        ids=ids[:width].unsqueeze(0);labels=labels[:width].unsqueeze(0)
        before=champion.model(ids)['logits'];after=candidate.model(ids)['logits']
        kl,count=full_sequence_kl(after,before,ids)
        targets=labels[:,1:];mask=targets!=-100
        teacher_nll=float(F.cross_entropy(before[:,:-1][mask].float(),targets[mask]))
        candidate_nll=float(F.cross_entropy(after[:,:-1][mask].float(),targets[mask]))
        records[key]=dict(language=row['language'],family=row['family'],full_sequence_kl=float(kl),
            real_next_token_positions=count,answer_nll_increase=candidate_nll-teacher_nll,
            teacher_complete_answer_correct=bool((before[:,:-1][mask].argmax(-1)==targets[mask]).all()),
            candidate_complete_answer_correct=bool((after[:,:-1][mask].argmax(-1)==targets[mask]).all()),
            full_sequence_argmax_changed=int((before[:,:-1].argmax(-1)!=after[:,:-1].argmax(-1)).sum()))
        if index%128==0:print(json.dumps(dict(phase='exhaustive TRAIN fullprompt audit',rows=index,seconds=time.monotonic()-start)),flush=True)
if any(hashlib.sha256(Path(p).read_bytes()).hexdigest()!=h for p,h in source_hashes.items()):raise AssertionError('source changed')
values=list(records.values())
audit=dict(scope='Read-only exhaustive initial518 certified TRAIN-bank rows, native approved champion versus fixed NEW endpoint; no optimization, no evaluation labels, no guarantee for unseen inputs',
    rows=len(values),max_full_sequence_kl=max(v['full_sequence_kl'] for v in values),
    mean_row_full_sequence_kl=sum(v['full_sequence_kl'] for v in values)/len(values),
    rows_above_sampled_kl_threshold=sum(v['full_sequence_kl']>.01 for v in values),
    max_answer_nll_increase=max(v['answer_nll_increase'] for v in values),
    rows_above_sampled_answer_nll_threshold=sum(v['answer_nll_increase']>.02 for v in values),
    all_teacher_answers_correct=all(v['teacher_complete_answer_correct'] for v in values),
    all_candidate_answers_correct=all(v['candidate_complete_answer_correct'] for v in values),
    real_next_token_positions=sum(v['real_next_token_positions'] for v in values),
    full_sequence_argmax_changed=sum(v['full_sequence_argmax_changed'] for v in values),
    records=records,seconds=time.monotonic()-start,source_checkpoint_unchanged=True)
trial['endpoint_exhaustive_train_bank_fullprompt_audit']=audit
report['harness_sha256']=hashlib.sha256((root/'retention-system-trial.py').read_bytes()).hexdigest()
report['read_only_fullprompt_audit_script_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
temporary=output.with_suffix('.json.tmp');temporary.write_text(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False));temporary.replace(output)
print(json.dumps({k:v for k,v in audit.items() if k!='records'}),flush=True)
