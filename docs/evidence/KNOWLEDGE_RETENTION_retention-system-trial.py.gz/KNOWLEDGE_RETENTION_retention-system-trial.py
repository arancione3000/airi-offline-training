"""Bounded paired checkpoint experiment; no publication or live adoption.

Reuses archived authored development and reviewed OASST2 splits exactly. Training
uses original TRAIN rows plus mechanically labelled TRAIN-only context values. The ancestral native reference and replay are verified from the pinned source.
The normal runner must still apply its original retention/final gates.
"""
import argparse
import sys
sys.path.insert(0, "/workspace/airi-offline-training/scripts/transfer-training")
import gc
import hashlib
import json
import math
from pathlib import Path
import random
import time

SCHEDULE = ('human-dialogue', 'verified-context', 'composition', 'old-authored',
            'human-dialogue', 'verified-context', 'curated-dialogue', 'native-replay',
            'human-dialogue', 'verified-context', 'composition', 'old-authored',
            'human-dialogue', 'verified-context', 'curated-dialogue', 'native-replay')


def paired_batch(batches):
    """Right padding is ignored by loss and cannot affect earlier causal logits."""
    import torch
    from generalist_lm.tokenizer import PAD
    width = max(ids.shape[1] for ids, labels in batches)
    ids = torch.full((len(batches), width), PAD, dtype=batches[0][0].dtype)
    labels = torch.full((len(batches), width), -100, dtype=batches[0][1].dtype)
    for index, (source_ids, source_labels) in enumerate(batches):
        ids[index, :source_ids.shape[1]] = source_ids[0]
        labels[index, :source_labels.shape[1]] = source_labels[0]
    return ids, labels


def trajectory_digest(trajectory):
    h = hashlib.sha256()
    for group, batch, retention, anchor in trajectory:
        h.update(group.encode())
        # Context is the intentional treatment; every other batch and ALL
        # retention/ancestral anchors must remain bitwise identical.
        entries = ([] if group == 'verified-context' else [batch]) + retention + [anchor]
        for encoded in entries:
            for tensor in encoded:
                h.update(str(tuple(tensor.shape)).encode())
                h.update(tensor.contiguous().cpu().numpy().tobytes())
    return h.hexdigest()



def main():
    from types import SimpleNamespace
    args=SimpleNamespace(checkpoint=Path('/workspace/airi-experiment/revision2/checkpoint/model'),
        archive=Path('/workspace/airi-experiment/revision2/experiment'),
        reference=Path('/workspace/airi-experiment/reference'),
        native_replay=Path('/workspace/airi-experiment/replay'),
        baseline_result=Path('/workspace/airi-experiment/completed-cycle/FINAL_RESULT.json'),
        output=Path('/workspace/airi-experiment/retention-system-trial.json'),
        seed=20261105, steps=192, learning_rate=3e-5, retention_weight=8.)
    resume_interrupted="--resume-new" in sys.argv
    prior_report=json.loads(args.output.read_text()) if resume_interrupted else None
    schedule=SCHEDULE
    retention_per_language=2
    import torch
    from torch.nn import functional as F
    from generalist_lm.runtime import GeneralistRuntime, checkpoint_model_files
    from generalist_lm.training import SFTExample, encode_sft_example
    from generalist_lm.phase5_diagnostics import protected_bootstrap_texts
    from generalist_lm.curriculum import train_rows
    from generalist_lm.bootstrap_data import load_bootstrap_replay
    from continual_learning import cache_tokenizer, continual_step, retention_rows, verified_memories
    from curriculum import norm, exact_correct, repetitive
    from success_bank import catalog, prompt_key, retains_correct_answers
    from human_data import load_corpus
    from policy import improved
    from fast_head import configure_head, install_feature_cache, head_summary, configure_projection, attach_projection
    from prefix_tuning import configure_prefix_tuning, prefix_summary

    torch.set_num_threads(2)
    torch.manual_seed(args.seed)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    source_files = checkpoint_model_files(args.checkpoint, verify=True)
    def file_digest(path):
        return hashlib.sha256(Path(path).read_bytes()).hexdigest()
    source_hashes = {str(path): file_digest(path) for path in source_files}
    champion = GeneralistRuntime.from_checkpoint(args.checkpoint)
    cache_tokenizer(champion.tokenizer)
    for parameter in champion.model.parameters():
        parameter.requires_grad_(False)
    champion.model.eval()
    install_feature_cache(champion.model, cache_bytes=64*1024*1024)
    reference = GeneralistRuntime.from_checkpoint(args.reference)
    if file_digest(args.reference/'model.pt') != '998530839d9722316b59cb28ff1ef68a7863f517de73fa8fef8ce9677a24b85e':
        raise ValueError('ancestral native reference changed')
    for parameter in reference.model.parameters():
        parameter.requires_grad_(False)
    reference.model.eval()
    install_feature_cache(reference.model, cache_bytes=64*1024*1024)
    baseline_saved = json.loads(args.baseline_result.read_text())['counters']['champion']
    dataset = json.loads((args.archive/'AUTHORED_CURRICULUM.json').read_text())
    authored, heldout, sealed = (dataset[key] for key in ('train', 'development', 'sealed_transfer'))
    spec = json.loads((args.archive/'SPEC.json').read_text())
    old_validation = [json.loads(line) for name in ('development.jsonl', 'test.jsonl')
                      for line in (args.archive/name).read_text().splitlines()]
    legacy_blocked = {norm(m['content']) for row in old_validation for m in row['messages']}
    protected = protected_bootstrap_texts() | legacy_blocked
    old_train = [json.loads(line) for line in (args.archive/'train-1024.jsonl').read_text().splitlines()]
    old_train = [row for row in old_train if not any(norm(m['content']) in protected for m in row['messages'])]
    def fits(row, length):
        return len(champion.tokenizer.serialize_messages(row['messages'][:-1], add_generation_prompt=True)) + len(champion.tokenizer.encode(row['messages'][-1]['content'], eos=True)) <= length
    # The pinned train-1024 source was already audited for complete1024 histories.
    if file_digest(args.archive/'train-1024.jsonl') != '4cd65b21228375b7abaf81da5e32e977dc1182f0a73b942dc81c34a38a698d91':
        raise ValueError('legacy source training corpus changed')
    old_human = [row for row in old_train if 2 <= len(row['messages']) <= 6
                 and 12 <= len(row['messages'][-1]['content'].encode()) <= 480]
    previous_text = {norm(m['content']) for row in old_human for m in row['messages']}
    blocked = legacy_blocked | {norm(p) for p in json.loads((args.archive/'CONVERSATION_TEST.json').read_text())['prompts']}
    all_heldout = {norm(m['content']) for row in heldout for m in row['messages']}
    acquisition_blocked = blocked | all_heldout | {norm(m['content']) for row in authored for m in row['messages']}
    corpus = load_corpus(args.archive, spec['human_corpus']['pins'], acquisition_blocked | previous_text,
                         training_blocked=acquisition_blocked)
    # Match the runner: at most sixteen examples PER language.
    human_dev = [row for lang in ('it', 'en')
                 for row in [r for r in corpus['development'] if r['language'] == lang][:16]]
    human_train = corpus['train']
    eligible = catalog(authored, heldout + sealed + corpus['development'] + corpus['final'])
    if {prompt_key(r) for r in authored} & {prompt_key(r) for r in heldout + sealed}:
        raise ValueError('authored training/heldout prompt overlap')
    dev_texts = {norm(m['content']) for split in ('development', 'final') for row in corpus[split] for m in row['messages']}
    if any(norm(m['content']) in dev_texts for row in human_train for m in row['messages']):
        raise ValueError('reviewed training/heldout text overlap')
    encoded_cache = {}
    def encode(row):
        key = json.dumps(row['messages'], ensure_ascii=False, sort_keys=True)
        if key not in encoded_cache:
            ids, labels = encode_sft_example(SFTExample.from_dict(row), champion.tokenizer, 1024, require_complete=True)
            scored = (labels != -100).nonzero()
            width = int(scored[:, 0].max()) + 1
            encoded_cache[key] = ids[:width].unsqueeze(0), labels[:width].unsqueeze(0)
        return encoded_cache[key]
    validation = [encode(row) for row in heldout]
    human_validation = [encode(row) for row in human_dev]
    memories = verified_memories(champion, retention_rows(list(eligible.values())), encode)
    memory_by = {lang: [encode(row) for row in memories if row['language'] == lang] for lang in ('it', 'en')}
    anchors = [{'messages': r.sft().messages} for r in train_rows()]
    anchors = [encode(row) for row in anchors if fits(row, 128) and not any(norm(m['content']) in protected for m in row['messages'])]
    if not anchors:
        raise ValueError('no native training anchors')
    replay_rows = {'language-it': [], 'language-en': [], 'domains': []}
    replay_source = load_bootstrap_replay(args.native_replay)
    for document in replay_source.documents:
        if document.source.startswith('tatoeba-it-'):
            group, prompt = 'language-it', 'Ripeti questa frase: '+document.text
        elif document.source.startswith('tatoeba-en-'):
            group, prompt = 'language-en', 'Repeat this sentence: '+document.text
        else:
            continue
        row = {'messages': [{'role':'user','content':prompt},{'role':'assistant','content':document.text}]}
        if not any(norm(m['content']) in protected for m in row['messages']) and fits(row,1024):
            replay_rows[group].append(row)
    replay_rows['domains'] = [{'messages':r.sft().messages} for r in train_rows()
                              if r.domain != 'language' and fits({'messages':r.sft().messages},128)
                              and not any(norm(m['content']) in protected for m in r.sft().messages)]
    selector = random.Random(71026)
    replay = {}
    for name, values in replay_rows.items():
        if not values:
            raise ValueError('empty exact native replay pool')
        if len(values)>512:
            values = selector.sample(values,512)
        replay[name] = [encode(row) for row in values]
    native = {lang: [r for r in authored if r['language'] == lang and not r['family'].startswith(('extra-', 'context-', 'foundation-'))] for lang in ('it', 'en')}
    curated = {lang: [r for r in authored if r['language'] == lang and (r['family'].startswith('extra-') or r['family'] == 'foundation-dialogue')] for lang in ('it', 'en')}
    context = {lang: [r for r in authored if r['language'] == lang and r['family'].startswith('context-') and r.get('stage', 0) == 0] for lang in ('it', 'en')}
    composition = {lang: [r for r in authored if r['language'] == lang and r['family'] in {'foundation-copy', 'foundation-recall'}] for lang in ('it', 'en')}
    humans = {lang: [r for r in human_train if r['language'] == lang] for lang in ('it', 'en')}
    print(json.dumps({'phase': 'data ready', 'authored': len(authored), 'development': len(heldout),
                      'human_counts': {k: len(v) for k,v in corpus.items()}, 'human_development': len(human_dev),
                      'certified_memories': len(memories), 'anchors': len(anchors)}), flush=True)

    def evaluate(runtime):
        runtime.model.eval()
        def grouped_nll(rows, batches):
            result = {}
            with torch.no_grad():
                for lang in ('it', 'en'):
                    total, count = 0., 0
                    for row, (ids, labels) in zip(rows, batches):
                        if row['language'] != lang:
                            continue
                        logits = runtime.model(ids)['logits'][:, :-1]
                        total += float(F.cross_entropy(logits.reshape(-1, logits.shape[-1]), labels[:, 1:].reshape(-1), reduction='sum'))
                        count += int((labels[:, 1:] != -100).sum())
                    if count:
                        result[lang] = total/count
            return result
        nll = grouped_nll(heldout, validation)
        human_nll = grouped_nll(human_dev, human_validation)
        samples = []
        with torch.no_grad():
            for old in baseline_saved['samples']:
                response = runtime.chat(old['messages'], temperature=0, max_new_tokens=64)
                samples.append({**old, 'response': response, 'correct': exact_correct(response, old['expected'])})
        contexts = [row for row in samples if row['family'].startswith('context-')]
        rates = {f'{lang}:{task}': sum(s['correct'] for s in contexts if s['language'] == lang and s['family'] == 'context-'+task)/sum(1 for s in contexts if s['language'] == lang and s['family'] == 'context-'+task) for lang in ('it', 'en') for task in ('name', 'location', 'topic', 'correction')}
        pairs = {s['pair_id'] for s in contexts}
        return {'human_nll': human_nll, 'human_development_rows': len(human_dev), 'nll': nll,
                'foundation_correct': sum(s['correct'] for s in samples if s['family'].startswith('foundation-')),
                'foundation_probes': sum(1 for s in samples if s['family'].startswith('foundation-')),
                'context_rates': rates, 'context_pair_rate': sum(all(s['correct'] for s in contexts if s['pair_id'] == pair) for pair in pairs)/len(pairs),
                'legacy_correct': sum(s['correct'] for s in samples if not s['family'].startswith(('extra-', 'context-', 'foundation-'))),
                'dialogue_correct': sum(s['correct'] for s in samples if s['family'].startswith('extra-')),
                'exact_correct': sum(s['correct'] for s in samples), 'probes': len(samples),
                'repetition': sum(repetitive(s['response']) for s in samples)/len(samples), 'samples': samples}
    tick = time.monotonic()
    before = prior_report["baseline"] if resume_interrupted else evaluate(champion)
    if before['exact_correct'] != baseline_saved['exact_correct'] or any(abs(before['nll'][k]-v) > 1e-5 for k,v in baseline_saved['nll'].items()) or any(abs(before['human_nll'][k]-v) > 1e-5 for k,v in baseline_saved['human_nll'].items()):
        raise ValueError('archived baseline not reproduced')
    print(json.dumps({'phase': 'baseline reproduced', 'exact_correct': before['exact_correct'], 'nll': before['nll'], 'human_nll': before['human_nll'], 'seconds': time.monotonic()-tick}), flush=True)
    from copy import deepcopy
    from generalist_lm.tokenizer import EOS
    from retention_memory import empty_memory, refresh, observe, sample_rows, make_certifier, summary, validate_memory
    from retention_guard import make_retention_guard
    from retention_transaction import transactional_update
    from success_bank import row_key, canonical
    from collections import Counter

    def json_write(path, value):
        temporary=path.with_suffix(path.suffix+'.tmp')
        temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False))
        temporary.replace(path)
    def tensor_digest(model):
        h=hashlib.sha256()
        for name,p in model.named_parameters():
            h.update(name.encode());h.update(p.detach().contiguous().numpy().tobytes())
        return h.hexdigest()
    def equal(left,right):
        if isinstance(left,torch.Tensor):return isinstance(right,torch.Tensor) and torch.equal(left,right)
        if type(left) is not type(right):return False
        if isinstance(left,dict):return left.keys()==right.keys() and all(equal(left[k],right[k]) for k in left)
        if isinstance(left,(list,tuple)):return len(left)==len(right) and all(equal(a,b) for a,b in zip(left,right))
        return left==right
    def tuples(value):
        return tuple(tuples(v) for v in value) if isinstance(value,list) else value
    def family_counts(rows):
        return dict(sorted(Counter(r['language']+':'+r['family'] for r in rows).items()))
    def quantities():
        return dict(physical_attempts=0,committed_updates=0,rejected_attempts=0,rejected_units=0,
                    physical_supervised_tokens=0,committed_supervised_tokens=0,
                    physical_reference_tokens=0,committed_reference_tokens=0,
                    physical_prompt_reference_tokens=0,committed_prompt_reference_tokens=0,
                    optimizer_seconds=0.,unit_seconds=0.,guard_setup_seconds=0.,guard_evaluation_seconds=0.)
    def account(total,result,physical_stats,started,guard_setup,guard_seconds):
        total['physical_attempts']+=len(physical_stats)
        total['committed_updates']+=int(result['accepted'])
        total['rejected_attempts']+=len(physical_stats)-int(result['accepted'])
        total['rejected_units']+=int(not result['accepted'])
        for kind in ('supervised_tokens','reference_tokens','prompt_reference_tokens'):
            total['physical_'+kind]+=sum(s.get(kind,0) for s,seconds in physical_stats)
            total['committed_'+kind]+=result['stats'].get(kind,0) if result['accepted'] else 0
        total['optimizer_seconds']+=sum(seconds for stats,seconds in physical_stats)
        total['unit_seconds']+=time.monotonic()-started
        total['guard_setup_seconds']+=guard_setup;total['guard_evaluation_seconds']+=guard_seconds
    def new_optimizer(model):
        return torch.optim.AdamW([p for p in model.parameters() if p.requires_grad],lr=args.learning_rate,weight_decay=.01)

    teacher_tensor_sha=tensor_digest(champion.model)
    reference_tensor_sha=tensor_digest(reference.model)
    cert_champion=make_certifier(champion.model,encode,EOS)
    legacy_eligible={row_key(r):r for r in memories}
    if len(legacy_eligible)!=278:raise AssertionError('legacy baseline must certify exact278')
    fingerprint='retention-system-trial-20261105-fixed192-v1'
    bank=refresh(teacher_tensor_sha,legacy_eligible,cert_champion,
                 empty_memory(fingerprint,capacity=1024),probe_limit=len(legacy_eligible))
    if set(bank['entries'])!=set(legacy_eligible):raise AssertionError('legacy migration lost a row')
    bank=refresh(teacher_tensor_sha,eligible,cert_champion,bank,probe_limit=256)
    initial_bank=deepcopy(bank)
    probe_keys=sorted(set(bank['entries'])|set(bank['probe_observations']))
    baseline_certificates={k:cert_champion(eligible[k]) for k in probe_keys}
    baseline_right={k for k,v in baseline_certificates.items() if v['correct']}
    old_keys=set(legacy_eligible)
    bank_keys=set(bank['entries'])
    if not old_keys<=bank_keys:raise AssertionError('all legacy knowledge must persist')
    bank_serialized=args.output.parent/'retention-system-trial-initial-bank.json'
    json_write(bank_serialized,bank)
    assert json.loads(bank_serialized.read_text())==bank
    validate_memory(json.loads(bank_serialized.read_text()),eligible,fingerprint,teacher_tensor_sha)

    # Acquisition and ancestral anchor are generated once, with RNGs independent
    # of retention selection, and reused bit-for-bit by both arms.
    acquisition_rng=random.Random(args.seed)
    anchor_rng=random.Random(args.seed+17)
    trajectory=[]
    for index in range(args.steps):
        lang='it' if index%3!=1 else 'en'
        group=schedule[index%16]
        if group=='human-dialogue':
            languages=sorted(humans)
            lang=acquisition_rng.choices(languages,weights=[math.sqrt(len(humans[k])) for k in languages],k=1)[0]
            batch=encode(acquisition_rng.choice(humans[lang]))
        elif group=='native-replay':
            batch=acquisition_rng.choice(replay[('language-it','language-en','domains')[(index//16)%3]])
        else:
            pool={'verified-context':context,'old-authored':native,'curated-dialogue':curated,'composition':composition}[group][lang]
            if group in ('old-authored','composition','verified-context'):
                family=acquisition_rng.choice(sorted({row['family'] for row in pool}))
                pool=[row for row in pool if row['family']==family]
            batch=encode(acquisition_rng.choice(pool))
        trajectory.append((group,batch,anchor_rng.choice(anchors)))
    commonhash=hashlib.sha256()
    for group,batch,anchor in trajectory:
        commonhash.update(group.encode())
        for ids,labels in (batch,anchor):
            for tensor in (ids,labels):
                commonhash.update(str(tuple(tensor.shape)).encode());commonhash.update(tensor.numpy().tobytes())
    code_paths=[Path('/workspace/airi-offline-training/scripts/transfer-training')/name for name in
                ('continual_learning.py','retention_memory.py','retention_transaction.py','retention_guard.py','prefix_tuning.py')]
    report=dict(scope='Fixed192-unit per arm real native checkpoint OLD/NEW retention comparison; no model adoption, no sealed forwards',
        seed=args.seed,steps_per_arm=args.steps,segment_units=64,source_files=source_hashes,
        reference_manifest_sha256=file_digest(args.reference/'model.pt'),
        code_hashes_at_start={str(p):file_digest(p) for p in code_paths},torch_version=torch.__version__,
        predeclared_profile=dict(learning_rate=3e-5,retention_weight=8.,target_kl_weight=8.,native_weight=.25,
            memories_per_unit=4,training='native last1 block plus head',new_full_sequence_kl_weight=8.,
            new_sentinel_rows=8,new_max_full_sequence_kl=.01,new_max_nll_regression=.02,new_retry_scales=[1,.5,.25,.125]),
        common_acquisition_anchor_sha256=commonhash.hexdigest(),schedule=schedule,
        acquisition_supervised_tokens=sum(int((b[1][:,1:]!=-100).sum()) for g,b,a in trajectory),
        heldout_training_overlap=False,baseline=before,
        initial_bank=summary(bank),initial_bank_family_counts=family_counts([v['row'] for v in bank['entries'].values()]),
        balanced_probe_family_counts=family_counts([eligible[k] for k in bank['probe_observations']]),
        ledger_baseline=dict(protected_legacy_rows=len(old_keys),protected_bank_rows=len(bank_keys),
            measured_train_rows=len(probe_keys),correct_measured_rows=len(baseline_right),
            coverage_added_before_training=len(bank_keys-old_keys),
            note='Coverage expansion certifies pre-existing TRAIN answers; it is not a training improvement'),
        trials=[],live_promoted=False,source_teacher_tensor_sha256=teacher_tensor_sha,
        original_reference_tensor_sha256=reference_tensor_sha,
        interpretation='Sampled guards do not guarantee whole-bank or unseen retention; endpoint certificates and original independent development gate are reported separately.')
    if prior_report:
        if (prior_report['common_acquisition_anchor_sha256']!=report['common_acquisition_anchor_sha256']
                or prior_report['predeclared_profile']!=report['predeclared_profile']
                or prior_report['source_files']!=report['source_files']):
            raise AssertionError('interrupted resume changed predeclared source/profile/trajectory')
        report=prior_report
        report['interruption']={'reason':'Harness compared Torch RNG after reload constructor had consumed it; all weights/Adam/statistics/bank/sampler checks passed',
            'recovery':'Continue saved native/Adam/JSON midpoint64, unchanged fixed192 logical trajectory; original development endpoint not repeated',
            'extra_discarded_physical_optimizer_attempts':2,
            'extra_discarded_attempts_timing_seconds':None,
            'missing_timing_reason':'Process-local clocks were lost on harness assertion; exact extra token exposures reconstructed from independently reproduced unit65'}
    json_write(args.output,report)
    print(json.dumps(dict(phase='pretraining ready' ,profile=report['predeclared_profile'],bank=summary(bank),
                         probes=len(probe_keys),common_sha256=commonhash.hexdigest())),flush=True)

    for arm in ('old-uniform-target-kl','new-persistent-transactional'):
        if any(t['arm']==arm for t in report['trials']):continue
        resuming=resume_interrupted and arm.startswith('new')
        resume_dir=args.output.parent/'retention-system-trial-new-midpoint'
        torch.manual_seed(args.seed)
        runtime=GeneralistRuntime.from_checkpoint(resume_dir if resuming else args.checkpoint)
        cache_tokenizer(runtime.tokenizer)
        configure_prefix_tuning(runtime.model)
        optimizer=new_optimizer(runtime.model)
        memory_rng=random.Random(args.seed+1)
        guard_rng=random.Random(args.seed+2)
        current_bank=deepcopy(initial_bank)
        adaptive={}
        accounting=quantities()
        validation_accounting=quantities()
        segments=[]
        updates=[]
        ledger={k:dict(first_correct_unit=0,currently_correct=True) for k in baseline_right}
        resume=None
        cert_candidate=make_certifier(runtime.model,encode,EOS)
        start_index=0
        if resuming:
            saved=json.loads((resume_dir/'TRAINING_STATE.json').read_text())
            saved_opt=torch.load(resume_dir/'OPTIMIZER.pt',weights_only=True)
            optimizer.load_state_dict(saved_opt['optimizer'])
            for name,p in runtime.model.named_parameters():
                if p.requires_grad:p.grad=saved_opt['gradients'][name]
            current_bank=saved['bank'];adaptive=saved['transaction']
            memory_rng.setstate(tuples(saved['memory_rng']));guard_rng.setstate(tuples(saved['guard_rng']))
            torch.set_rng_state(torch.tensor(saved['torch_rng'],dtype=torch.uint8))
            segments=deepcopy(report['running_trial']['segments'])
            accounting=deepcopy(segments[-1]['accounting'])
            start_index=64
            del saved,saved_opt
        def unit(index,rt,opt,working_bank,txstate,mrng,grng,total):
            start=time.monotonic()
            group,batch,anchor=trajectory[index]
            physical=[]
            if arm.startswith('new'):
                memory_rows=sample_rows(working_bank,eligible,mrng,per_language=2)
                sentinel_rows=sample_rows(working_bank,eligible,grng,per_language=4)
                retention=[encode(r) for r in memory_rows]
                tick=time.monotonic()
                guarded=make_retention_guard(rt.model,champion.model,[encode(r) for r in sentinel_rows],
                                             max_prompt_kl=.01,max_nll_regression=.02)
                guard_setup=time.monotonic()-tick
            else:
                memory_rows=[memory_rng.choice([r for r in memories if r['language']==lang]) for lang in ('it','en') for _ in range(2)]
                sentinel_rows=[];retention=[encode(r) for r in memory_rows];guard_setup=0.
            def propose():
                tick=time.monotonic()
                stats=continual_step(rt.model,champion.model,reference.model,opt,batch,retention,anchor,
                                     retention_weight=8.,champion_kl_weight=8.,native_weight=.25,
                                     prompt_kl_weight=8. if arm.startswith('new') else 0.)
                physical.append((dict(stats),time.monotonic()-tick))
                return stats
            guard_seconds=0.
            def timed_guard():
                nonlocal guard_seconds
                tick=time.monotonic();answer=guarded();guard_seconds+=time.monotonic()-tick
                return answer
            if arm.startswith('new'):
                result=transactional_update(rt.model,opt,propose,timed_guard,state=txstate,
                                            scales=(1,.5,.25,.125),sampler_rngs=(mrng,grng))
                observed_keys=list(dict.fromkeys(row_key(r) for r in memory_rows+sentinel_rows))
                observed=observe(working_bank,eligible,make_certifier(rt.model,encode,EOS),observed_keys)
                working_bank.clear();working_bank.update(observed)
            else:
                stats=propose();result=dict(accepted=True,attempts=1,scale=1.,stats=stats,guard={})
            account(total,result,physical,start,guard_setup,guard_seconds)
            return dict(unit=index+1,group=group,accepted=result['accepted'],attempts=result['attempts'],
                        scale=result['scale'],stats=result['stats'],guard=result['guard'],
                        memory_keys=[row_key(r) for r in memory_rows],sentinel_keys=[row_key(r) for r in sentinel_rows])

        for index in range(start_index,args.steps):
            # JSON metadata + native model + actual Adam state at a continuous
            # midpoint are used to reproduce the exact next update independently.
            if index==64 and arm.startswith('new'):
                resume_dir=args.output.parent/'retention-system-trial-new-midpoint'
                runtime.save_checkpoint(resume_dir,metadata=dict(production_qualified=False,live_promoted=False,role='isolated-midtrajectory-resume'))
                resume_json=dict(next_unit=index+1,bank=current_bank,transaction=adaptive,
                                 memory_rng=memory_rng.getstate(),guard_rng=guard_rng.getstate(),torch_rng=torch.get_rng_state().tolist())
                json_write(resume_dir/'TRAINING_STATE.json',resume_json)
                torch.save(dict(optimizer=optimizer.state_dict(),
                                gradients={name:None if p.grad is None else p.grad.clone() for name,p in runtime.model.named_parameters() if p.requires_grad}),
                           resume_dir/'OPTIMIZER.pt')
                resume=dict(path=str(resume_dir),step=64,verification_pending=True)
            update=unit(index,runtime,optimizer,current_bank,adaptive,memory_rng,guard_rng,accounting)
            updates.append(update)
            if index==64 and arm.startswith('new'):
                saved=json.loads((resume_dir/'TRAINING_STATE.json').read_text())
                current_torch_rng=torch.get_rng_state().clone()
                restored=GeneralistRuntime.from_checkpoint(resume_dir)
                configure_prefix_tuning(restored.model)
                restored_optimizer=new_optimizer(restored.model)
                saved_opt=torch.load(resume_dir/'OPTIMIZER.pt',weights_only=True)
                restored_optimizer.load_state_dict(saved_opt['optimizer'])
                for name,p in restored.model.named_parameters():
                    if p.requires_grad:p.grad=saved_opt['gradients'][name]
                restored_bank=saved['bank'];restored_tx=saved['transaction']
                restored_mrng=random.Random();restored_mrng.setstate(tuples(saved['memory_rng']))
                restored_grng=random.Random();restored_grng.setstate(tuples(saved['guard_rng']))
                torch.set_rng_state(torch.tensor(saved['torch_rng'],dtype=torch.uint8))
                duplicate=unit(index,restored,restored_optimizer,restored_bank,restored_tx,restored_mrng,restored_grng,validation_accounting)
                names=[name for name,p in runtime.model.named_parameters() if p.requires_grad]
                target=dict(runtime.model.named_parameters());actual=dict(restored.model.named_parameters())
                checks=dict(trainable_weights_exact=all(torch.equal(target[n],actual[n]) for n in names),
                    optimizer_exact=equal(optimizer.state_dict(),restored_optimizer.state_dict()),
                    bank_json_exact=current_bank==restored_bank,transaction_json_exact=adaptive==restored_tx,
                    memory_rng_exact=memory_rng.getstate()==restored_mrng.getstate(),
                    guard_rng_exact=guard_rng.getstate()==restored_grng.getstate(),
                    torch_rng_exact=torch.equal(current_torch_rng,torch.get_rng_state()),update_statistics_exact=update==duplicate)
                torch.set_rng_state(current_torch_rng)
                if not all(checks.values()):raise AssertionError('midtrajectory exact resume failed:'+str(checks))
                resume.update(checks);resume['verification_pending']=False
                if resuming:
                    extra=report['interruption']
                    for kind in ('supervised_tokens','reference_tokens','prompt_reference_tokens'):
                        extra['extra_discarded_physical_'+kind]=2*update['stats'].get(kind,0)
                del restored,restored_optimizer,saved_opt,restored_bank
                gc.collect()
                print(json.dumps(dict(phase='resume verified',arm=arm,checks=checks)),flush=True)
            if (index+1)%64==0:
                tick=time.monotonic()
                observations={k:cert_candidate(eligible[k]) for k in probe_keys}
                now_right={k for k,v in observations.items() if v['correct']}
                for key in now_right:
                    ledger.setdefault(key,dict(first_correct_unit=index+1))
                for key,entry in ledger.items():entry['currently_correct']=key in now_right
                if arm.startswith('new'):
                    current_bank=observe(current_bank,eligible,cert_candidate)
                    if set(current_bank['entries'])!=bank_keys:raise AssertionError('ledger membership changed silently')
                segment=dict(unit=index+1,correct_measured_train_rows=len(now_right),
                    protected_old_rows=len(old_keys),old_correct=len(old_keys & now_right),old_lost=sorted(old_keys-now_right),
                    protected_bank_rows=len(bank_keys),bank_correct=len(bank_keys & now_right),bank_lost=sorted(bank_keys-now_right),
                    newly_correct_vs_baseline=sorted(now_right-baseline_right),
                    lost_vs_baseline=sorted(baseline_right-now_right),
                    ledger_entries_ever_correct=len(ledger),ledger_entries_currently_correct=sum(v['currently_correct'] for v in ledger.values()),
                    evaluation_seconds=time.monotonic()-tick,accounting=deepcopy(accounting),transaction=deepcopy(adaptive),
                    persistent_bank=summary(current_bank) if arm.startswith('new') else None)
                segments.append(segment)
                print(json.dumps(dict(phase='segment complete',arm=arm,unit=index+1,train_correct=len(now_right),
                    train_new=len(now_right-baseline_right),old_lost=len(old_keys-now_right),bank_lost=len(bank_keys-now_right),
                    physical_attempts=accounting['physical_attempts'],commits=accounting['committed_updates'],scale=adaptive.get('lr_scale',1))),flush=True)
                report['running_trial']=dict(arm=arm,segments=segments,resume=resume)
                json_write(args.output,report)
        after=evaluate(runtime)
        gate=improved(before,after) and retains_correct_answers(before,after)
        destination=args.output.parent/('retention-system-trial-'+arm+'-candidate')
        runtime.save_checkpoint(destination,metadata=dict(production_qualified=False,live_promoted=False,role='isolated-retention-comparison'))
        exported=GeneralistRuntime.from_checkpoint(destination)
        exported.model.eval();runtime.model.eval()
        with torch.no_grad():
            export_exact=torch.equal(exported.model(trajectory[0][1][0])['logits'],runtime.model(trajectory[0][1][0])['logits'])
        if not export_exact:raise AssertionError('native export changed exact logits')
        del exported
        final_bank_observations={k:cert_candidate(eligible[k]) for k in sorted(bank_keys)}
        final_lost=[k for k,v in final_bank_observations.items() if not v['correct']]
        trial=dict(arm=arm,strategy=prefix_summary(runtime.model),accounting=accounting,
            resume_validation_extra_physical_accounting=validation_accounting,resume=resume,segments=segments,
            update_ledger=updates,update_ledger_scope='units65..192 with first64 aggregate in segment checkpoint' if resuming else 'all192 units',
            knowledge_growth_ledger=ledger,after=after,
            original_development_gate_accepted=gate,original_development_and_all_train_retained=gate and not final_lost,
            lost_answers=[i for i,(a,b) in enumerate(zip(before['samples'],after['samples'])) if a['correct'] and not b['correct']],
            gained_answers=[i for i,(a,b) in enumerate(zip(before['samples'],after['samples'])) if not a['correct'] and b['correct']],
            endpoint_full_bank_certificates=final_bank_observations,endpoint_full_bank_lost=final_lost,
            endpoint_old_memory_lost=sorted(set(final_lost)&old_keys),
            persistent_bank_membership_preserved=set(current_bank['entries'])==bank_keys,
            endpoint_bank_json=current_bank if arm.startswith('new') else None,
            native_export_logits_exact=export_exact,candidate=str(destination),live_promoted=False)
        if resuming:
            trial['interruption_extra_physical_accounting']=deepcopy(report['interruption'])
            trial['physical_attempts_including_resume_validation_and_discarded']=accounting['physical_attempts']+validation_accounting['physical_attempts']+2
            trial['physical_tokens_including_resume_validation_and_discarded']={
                kind:accounting['physical_'+kind]+validation_accounting['physical_'+kind]+report['interruption']['extra_discarded_physical_'+kind]
                for kind in ('supervised_tokens','reference_tokens','prompt_reference_tokens')}
        report['trials'].append(trial);report.pop('running_trial',None)
        json_write(args.output,report)
        print(json.dumps(dict(phase='arm endpoint',arm=arm,exact_correct=after['exact_correct'],nll=after['nll'],human_nll=after['human_nll'],
            development_gate_accepted=gate,old_lost=trial['lost_answers'],gained=trial['gained_answers'],
            bank_lost=len(final_lost),physical_attempts=accounting['physical_attempts'],commits=accounting['committed_updates'])),flush=True)
        del runtime,optimizer,cert_candidate,current_bank
        gc.collect()
    if any(file_digest(path)!=digest for path,digest in source_hashes.items()):raise AssertionError('source checkpoint changed')
    if tensor_digest(champion.model)!=teacher_tensor_sha:raise AssertionError('frozen champion changed in memory')
    if tensor_digest(reference.model)!=reference_tensor_sha:raise AssertionError('frozen ancestral teacher changed in memory')
    report.update(source_checkpoint_unchanged=True,frozen_champion_unchanged=True,frozen_ancestral_reference_unchanged=True,
                  code_hashes_at_end={str(p):file_digest(p) for p in code_paths},complete=True)
    json_write(args.output,report)
    print(json.dumps(dict(phase='complete',output=str(args.output),source_unchanged=True,live_promoted=False)),flush=True)

if __name__=='__main__':
    main()
