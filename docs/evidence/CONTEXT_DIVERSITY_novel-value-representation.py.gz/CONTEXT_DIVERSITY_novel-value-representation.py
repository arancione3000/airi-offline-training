"""Read-only TRAIN-only A-Z literal-identity diagnostic on native rev2.

Fit auxiliary ridge readouts on frozen vectors, with disjoint literal values
in fit/test. This is not a language-model benchmark or an inference adapter.
No evaluation dataset is opened, encoded, or forwarded; no optimizer exists.
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import string
import sys

import torch
from torch.nn import functional as F

sys.path.insert(0, '/workspace/airi-offline-training/scripts/transfer-training')
import context_acquisition
from context_acquisition import build_context_acquisition, acquisition_audit
from continual_learning import cache_tokenizer
from generalist_lm.runtime import GeneralistRuntime, checkpoint_model_files


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def counts(rows, field):
    return dict(sorted(Counter(str(row[field]) for row in rows).items()))


def value_partition(rows):
    # Stratification depends only on mechanical A-Z labels and value strings.
    # The union makes literal values globally disjoint across both languages.
    test_values = set()
    for language in ('it', 'en'):
        for char in string.ascii_uppercase:
            values = {r['expected'] for r in rows
                      if r['language'] == language and r['expected'][0] == char}
            ordered = sorted(values, key=lambda value: hashlib.sha256(
                ('novel-literal-readout-v1\0' + value).encode()).digest())
            if len(ordered) < 4:
                raise AssertionError('insufficient independent values per class')
            test_values.update(ordered[:max(2, len(ordered) // 4)])
    fit = [i for i, r in enumerate(rows) if r['expected'] not in test_values]
    test = [i for i, r in enumerate(rows) if r['expected'] in test_values]
    assert not ({rows[i]['expected'] for i in fit} & {rows[i]['expected'] for i in test})
    summary = {}
    for language in ('it', 'en'):
        summary[language] = {}
        for partition, indices in [('fit', fit), ('test', test)]:
            selected = [rows[i] for i in indices if rows[i]['language'] == language]
            char_counts = Counter(r['expected'][0] for r in selected)
            assert set(char_counts) == set(string.ascii_uppercase)
            summary[language][partition] = {
                'rows': len(selected), 'unique_values': len({r['expected'] for r in selected}),
                'class_counts': dict(sorted(char_counts.items())),
                'length_buckets': counts(selected, 'length_bucket'),
                'template_indices': counts(selected, 'template_index'),
                'history_exchanges': counts(selected, 'history_exchanges'),
            }
    return fit, test, summary


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--checkpoint', type=Path, default=Path('/workspace/airi-experiment/revision2/checkpoint/model'))
    p.add_argument('--output', type=Path, default=Path('/workspace/airi-experiment/novel-value-representation.json'))
    args = p.parse_args()
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    torch.manual_seed(20261104)
    checkpoint_files = checkpoint_model_files(args.checkpoint, verify=True)
    checkpoint_hashes = {str(path): digest(path) for path in checkpoint_files}
    builder_path = Path(context_acquisition.__file__)
    builder_hash = digest(builder_path)
    pool = build_context_acquisition()
    pool_audit = acquisition_audit(pool)
    selected = [r for r in pool if r['family'] == 'context-name']
    assert len(pool) == 2048 and len(selected) == 512
    assert all(r['expected'][0] in string.ascii_uppercase for r in selected)
    fit_indices, test_indices, split_summary = value_partition(selected)
    print(json.dumps({'phase': 'partition', 'rows': len(selected), 'split': split_summary}), flush=True)
    rt = GeneralistRuntime.from_checkpoint(args.checkpoint)
    rt.model.eval()
    for parameter in rt.model.parameters():
        parameter.requires_grad_(False)
    cache_tokenizer(rt.tokenizer)
    features, records, current, handles = {}, [], {}, []
    layers = [0, 4, 8, 10, 11]

    def capture_input(module, inputs):
        current['embedding'] = inputs[0].detach()

    def capture_output(index):
        def hook(module, inputs, output):
            current[f'block{index}'] = output[0].detach()
        return hook

    handles.append(rt.model.blocks[0].register_forward_pre_hook(capture_input))
    for index in layers:
        handles.append(rt.model.blocks[index].register_forward_hook(capture_output(index)))

    try:
        with torch.no_grad():
            for index, row in enumerate(selected):
                content = row['messages'][0]['content']
                raw, value_bytes = content.encode('utf-8'), row['expected'].encode('utf-8')
                # A one-letter value may appear earlier in ordinary prose.
                # Match the exact quoted insertion rather than raw .index(value).
                marker = '«'.encode() + value_bytes + '»'.encode()
                assert raw.count(marker) == 1
                start = raw.index(marker) + len('«'.encode())
                end = start + len(row['expected'][0].encode('utf-8'))
                content_ids = rt.tokenizer.encode(content)
                token_bytes = [rt.tokenizer.token_bytes(t) for t in content_ids]
                assert b''.join(token_bytes) == raw
                prompt = rt.tokenizer.serialize_messages(row['messages'][:-1], add_generation_prompt=True)
                assert prompt[2:2 + len(content_ids)] == content_ids
                offset, overlaps = 0, []
                for token_index, data in enumerate(token_bytes):
                    if offset < end and offset + len(data) > start:
                        overlaps.append((token_index + 2, offset, offset + len(data), content_ids[token_index], data))
                    offset += len(data)
                assert len(overlaps) == 1  # A-Z is exactly one UTF8 byte.
                source_position, token_start, token_end, token_id, data = overlaps[0]
                assert len(prompt) <= rt.model.config.context_length
                current.clear()
                output = rt.model(torch.tensor([prompt]))
                del output
                for layer, hidden in current.items():
                    for place, vector in [('source_first_character_token', hidden[0, source_position]),
                                          ('question_tail', hidden[0, -1])]:
                        features.setdefault((layer, place), []).append(vector.cpu().double())
                record = {k: row[k] for k in ('language', 'expected', 'length_bucket', 'template_index',
                                                'history_exchanges', 'pair_id', 'counterfactual_index')}
                record.update(label=row['expected'][0], partition='test' if index in test_indices else 'fit',
                              prompt_tokens=len(prompt), source_first_character_position=source_position,
                              source_first_character_byte_span=[start, end],
                              source_overlapping_token_byte_span=[token_start, token_end],
                              source_overlapping_token_id=token_id,
                              source_overlapping_token_bytes=list(data),
                              token_contains_other_characters=token_start != start or token_end != end)
                records.append(record)
                if (index + 1) % 64 == 0:
                    print(json.dumps({'phase': 'frozen_forward', 'rows': index + 1}), flush=True)
    finally:
        for handle in handles:
            handle.remove()

    readouts = []
    for language in ('it', 'en'):
        fit = [i for i in fit_indices if records[i]['language'] == language]
        test = [i for i in test_indices if records[i]['language'] == language]
        fit_labels = torch.tensor([ord(records[i]['label']) - ord('A') for i in fit])
        test_labels = torch.tensor([ord(records[i]['label']) - ord('A') for i in test])
        class_counts = Counter(int(label) for label in fit_labels)
        majority_label = min(class_counts, key=lambda label: (-class_counts[label], label))
        majority_test = float((test_labels == majority_label).double().mean())
        for (layer, place), values in features.items():
            X = torch.stack(values)
            mean = X[fit].mean(0)
            train, target = F.normalize(X[fit] - mean, dim=-1), F.one_hot(fit_labels, 26).double()
            gram = train @ train.T
            coefficients = torch.linalg.solve(gram + .01 * torch.eye(len(fit), dtype=torch.double), target)
            predictions = (F.normalize(X[test] - mean, dim=-1) @ train.T @ coefficients).argmax(-1)
            hits = predictions == test_labels
            by_bucket = {}
            for bucket in range(4):
                positions = [j for j, i in enumerate(test) if records[i]['length_bucket'] == bucket]
                by_bucket[str(bucket)] = {'correct': int(hits[positions].sum()), 'rows': len(positions),
                                         'accuracy': float(hits[positions].double().mean()) if positions else None}
            per_class = {char: {'correct': int(hits[test_labels == k].sum()),
                                'rows': int((test_labels == k).sum())}
                         for k, char in enumerate(string.ascii_uppercase)}
            readouts.append({'language': language, 'layer': layer, 'position': place,
                             'fit_rows': len(fit), 'test_rows': len(test), 'classes': 26,
                             'correct': int(hits.sum()), 'accuracy': float(hits.double().mean()),
                             'macro_accuracy': sum(r['correct'] / r['rows'] for r in per_class.values()) / 26,
                             'uniform_chance_accuracy': 1 / 26,
                             'fit_majority_label': chr(majority_label + ord('A')),
                             'fit_majority_predictor_test_accuracy': majority_test,
                             'test_largest_class_fraction': max(Counter(int(x) for x in test_labels).values()) / len(test),
                             'ridge': .01, 'per_class': per_class, 'by_length_bucket': by_bucket})

    hashes_after = {str(path): digest(path) for path in checkpoint_files}
    if checkpoint_hashes != hashes_after:
        raise AssertionError('source checkpoint changed')
    assert all(parameter.grad is None for parameter in rt.model.parameters())
    result = {
        'scope': 'TRAIN-only auxiliary readout; no optimizer, parameter update, evaluation-set access, or evaluation-set forward',
        'checkpoint': str(args.checkpoint), 'source_checkpoint_files_sha256': checkpoint_hashes,
        'source_checkpoint_unchanged': True, 'model_training': rt.model.training,
        'source_checkpoint_unchanged_scope': 'model.pt manifest and its weight shards listed in source_checkpoint_files_sha256; config/tokenizer are not included in this before/after hash assertion',
        'all_parameter_gradients_absent': True, 'torch_num_threads': torch.get_num_threads(),
        'context_builder': str(builder_path), 'context_builder_sha256_at_start': builder_hash,
        'context_builder_sha256_at_end': digest(builder_path), 'pool_audit': pool_audit,
        'selected_family': 'context-name', 'selected_rows': len(selected),
        'selected_unique_values': len({r['expected'] for r in selected}),
        'label_definition': 'exact first ASCII uppercase character of the generated literal value: expected[0], A-Z',
        'split_definition': '75/25 approximately, stratified by initial and language; union of test values makes fit/test globally value-disjoint; all 26 classes in each language fit/test',
        'split': split_summary, 'value_overlap_fit_test': [],
        'feature_definition': 'source token whose UTF8 byte span contains the first literal A-Z character; question-tail is final assistant role token; embedding is input to block0 including position',
        'tokenization_ambiguities': {
            'rows_with_token_containing_additional_characters': sum(r['token_contains_other_characters'] for r in records),
            'overlap_multiple_tokens': 0,
            'note': 'Token labels are literal A-Z characters, not first target BPE token IDs; adjacent token bytes are recorded for every row. Source value is located through its unique quoted insertion.',
        },
        'readout_method': 'train-centered unit-normalized hidden vectors; 26-class one-hot ridge readout with fixed lambda .01; no tuning on test; per-language fitting; independent readout per layer/position',
        'readouts': readouts, 'records': records,
        'limitations': [
            'These TRAIN-generated literal values are held out only from auxiliary readout fitting, not a claim that their constituent characters are unseen by the model.',
            'High source-position first-character recovery does not establish recovery of the full value, sequence copying, language-model answer generation, causal access at the output, or benchmark improvement.',
            'Fit/test share authored TRAIN template families; disjoint values test literal generalization rather than unseen-template generalization.',
            'Question-tail classification may exploit positional or template/label correlations; no causal intervention or label-shuffling control is claimed.',
            'Only one fixed ridge regularization and 512 generated context-name rows are measured; other tasks and complete target strings are outside this diagnostic.',
        ],
    }
    args.output.write_text(json.dumps(result, indent=2, ensure_ascii=False, allow_nan=False))
    print(json.dumps({'phase': 'complete', 'output': str(args.output),
                      'source_checkpoint_unchanged': True,
                      'tokenization_ambiguities': result['tokenization_ambiguities'],
                      'readouts': [{k: r[k] for k in ('language', 'layer', 'position', 'correct', 'test_rows', 'accuracy',
                                                     'fit_majority_predictor_test_accuracy')} for r in readouts]}, indent=2), flush=True)


if __name__ == '__main__':
    main()
