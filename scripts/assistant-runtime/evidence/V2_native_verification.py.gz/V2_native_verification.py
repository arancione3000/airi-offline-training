import gzip, hashlib, json, random, sys, time
from pathlib import Path
import torch
torch.set_num_threads(2)
ROOT=Path('/workspace/airi-offline-training')
sys.path.insert(0,str(ROOT/'scripts/assistant-runtime'))
from assistant import AiriAssistant
from chat import VerifiedNative
out=Path('/workspace/airi-lab/assistant-runtime-v2')
record=json.loads((out/'approved-record.json').read_text())
old=json.loads(gzip.decompress((ROOT/'scripts/research-training/learnability-20261115/evidence/REPORT.json.gz').read_bytes()))['baseline']['samples']
native=VerifiedNative(cache=out/'unused-cache',checkpoint=Path('/workspace/airi-lab/rev4/checkpoint'),record=record)
first=next(r for r in old if r['correct']);first_answer=native(first['messages'])
assert first_answer==first['expected']
runtime=native.runtime
state=torch.random.get_rng_state().clone()
def fallback(messages):return runtime.chat(messages,temperature=0,max_new_tokens=64)
assistant=AiriAssistant(fallback)
print(json.dumps({'phase':'verified native adapter loaded','revision':record['revision']}),flush=True)
results=[];start=time.monotonic()
for i,row in enumerate(old):
 answer=assistant.respond(row['messages'])
 results.append(dict(index=i,expected=row['expected'],baseline_response=row['response'],baseline_correct=row['correct'],
                     answer=answer['answer'],source=answer['source'],correct=answer['answer']==row['expected']))
report={'scope':'actual composed memory + same native source inference; not neural weight improvement',
 'revision':record['revision'],'weights_digest':record['weights_digest'],'legacy92':{
 'correct':sum(r['correct'] for r in results),'lost':sum(r['baseline_correct'] and not r['correct'] for r in results),
 'observations':results},'legacy_seconds':time.monotonic()-start}
(out/'NATIVE_VERIFICATION.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'phase':'actual composed92','correct':report['legacy92']['correct'],'old_correct_lost':report['legacy92']['lost']}),flush=True)
cases=json.loads((out/'CASES.json').read_text());positive=[r for r in cases if r['expected'] is not None]
sample=random.Random(202611152255).sample(positive,32);values=[]
for row in sample:
 native_answer=fallback(row['messages']);composed=assistant.respond(row['messages'])
 values.append(dict(id=row['id'],expected=row['expected'],native_answer=native_answer,native_correct=native_answer==row['expected'],
                    composed_answer=composed['answer'],composed_correct=composed['answer']==row['expected'],source=composed['source']))
assert torch.equal(torch.random.get_rng_state(),state)
report['fresh32']={'seed':202611152255,'native_correct':sum(r['native_correct'] for r in values),
                   'composed_correct':sum(r['composed_correct'] for r in values),'observations':values}
report['greedy_rng_unchanged']=True;report['complete']=True
(out/'NATIVE_VERIFICATION.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'phase':'complete','native_fresh32':report['fresh32']['native_correct'],
 'composed_fresh32':report['fresh32']['composed_correct'],'legacy92':report['legacy92']['correct']}),flush=True)
