"""Bounded learned question routing after stable memory and exact experts.

The original request is classified globally before source compatibility is
checked. Query rewriting is internal and preserves original source provenance.
"""
from pathlib import Path

import query_router
import skill_programs
from skill_bank import RegistryError

DEFAULT_MODEL=Path(__file__).resolve().parent/'queries/approved-router.json'


class LearnedQueryRouter:
    def __init__(self,bank,path=DEFAULT_MODEL,*,frozen=False):
        self.bank=bank;self.path=Path(path)
        self.snapshot=bank._read()[0] if frozen else None

    def predict(self,messages):
        if skill_programs._eligible(messages) is None:return None
        original=messages[-1]['content']
        try:
            model=query_router.read_model(self.path)
            route=query_router.predict(model,original)
        except (ValueError,TypeError,KeyError,RecursionError) as error:
            raise RegistryError('learned query model unavailable') from error
        if route is None:return None
        state=self.snapshot if self.snapshot is not None else self.bank._read()[0]
        bindings={row['program_id']:row for row in model['bindings']}
        compatible=[]
        for entry in state['entries']:
            binding=bindings.get(entry['id'])
            if binding is None:continue
            if binding['canonical_query']!=entry['program']['query']:raise RegistryError('query binding mismatch')
            rewritten=list(messages);rewritten[-1]={**messages[-1],'content':binding['canonical_query']}
            result=skill_programs.predict(entry['program'],rewritten)
            if result is not None:compatible.append((entry,binding,result))
        if len(compatible)!=1:return None
        entry,binding,result=compatible[0]
        if binding['lesson_id']!=route['lesson_id']:return None
        return {**result,'skill_id':entry['id'],'skill_revision':state['revision'],
                'routing':'learned_paraphrase','query_provenance':{
                    'original_query':original,'canonical_query':binding['canonical_query'],
                    **route}}
